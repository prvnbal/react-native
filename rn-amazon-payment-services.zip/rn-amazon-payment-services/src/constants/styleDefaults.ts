export const CUSTOM_UI_VIEW_HEIGHT = 500;
export const CUSTOM_UI_VIEW_WIDTH = 320;
export const DIRECT_PAY_VIEW_HEIGHT = 300;
export const DIRECT_PAY_VIEW_WIDTH = 300;
