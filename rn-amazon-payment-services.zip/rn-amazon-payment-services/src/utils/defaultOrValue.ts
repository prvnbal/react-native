const defaultOrValue = (defaultValue: any, value?: any) => {
  return value ? value : defaultValue;
};

export default defaultOrValue;
