#ifndef RnAmazonPaymentServiceSdk_h
#define RnAmazonPaymentServiceSdk_h


#endif /* RnAmazonPaymentServiceSdk_h */

#import <React/RCTBridgeModule.h>
@interface RnAmazonPaymentServiceSdk : NSObject <RCTBridgeModule>
@end
