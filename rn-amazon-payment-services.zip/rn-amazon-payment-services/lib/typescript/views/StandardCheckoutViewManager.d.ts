import * as React from 'react';
import type { standardCheckoutViewProps } from '../types/viewProps';
declare const StandardCheckoutViewManager: React.FC<standardCheckoutViewProps>;
export default StandardCheckoutViewManager;
