import * as React from 'react';
import type { customCheckoutViewProps } from '../types/viewProps';
declare const CustomCheckoutViewManager: React.FC<customCheckoutViewProps>;
export default CustomCheckoutViewManager;
