import * as React from 'react';
import type { customCheckoutViewProps } from '../types/viewProps';
declare const DirectPayManager: React.FC<customCheckoutViewProps>;
export default DirectPayManager;
