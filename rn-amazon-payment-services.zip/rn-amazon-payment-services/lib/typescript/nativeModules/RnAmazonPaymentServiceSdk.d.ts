export declare const LINKING_ERROR: string;
declare const RnAmazonPaymentServiceSdk: any;
export default RnAmazonPaymentServiceSdk;
