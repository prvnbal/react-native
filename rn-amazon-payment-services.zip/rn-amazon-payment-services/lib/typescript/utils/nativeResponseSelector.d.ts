declare const nativeResponseSelector: (response: any) => any;
export default nativeResponseSelector;
