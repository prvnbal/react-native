declare const adjustedDefaultOrValue: (defaultValue: any, value?: any, withMultiplier?: boolean) => number;
export default adjustedDefaultOrValue;
