declare const checkColorOrDefault: (defaultColor: string, hexColor?: string) => string;
export default checkColorOrDefault;
