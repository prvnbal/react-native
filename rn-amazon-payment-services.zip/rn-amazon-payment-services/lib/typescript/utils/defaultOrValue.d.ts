declare const defaultOrValue: (defaultValue: any, value?: any) => any;
export default defaultOrValue;
