import type { RequestObject } from '../types/requestObject';
export declare function callFortRequest(onSuccess: any, onFailure: any, onCancel: any, requestObject: RequestObject, environment: 'TEST' | 'PRODUCTION', requestCode: any, showLoading: boolean, showResponsePage: boolean): void;
