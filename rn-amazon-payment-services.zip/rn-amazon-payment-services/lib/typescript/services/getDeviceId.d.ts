export declare function getSDKDeviceId(): Promise<string>;
