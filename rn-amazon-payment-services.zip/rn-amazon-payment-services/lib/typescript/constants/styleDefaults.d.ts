export declare const CUSTOM_UI_VIEW_HEIGHT = 500;
export declare const CUSTOM_UI_VIEW_WIDTH = 320;
export declare const DIRECT_PAY_VIEW_HEIGHT = 300;
export declare const DIRECT_PAY_VIEW_WIDTH = 300;
